//
//  TasksView.swift
//  Wokey-Toky
//
//  Created by 조수민 on 5/7/26.
//

import SwiftUI
import SwiftData

struct TasksView: View {
    @Environment(\.modelContext) private var modelContext

    @Query(sort: \TaskItem.createdAt, order: .reverse)
    private var tasks: [TaskItem]
    
    @Query(sort: \ActivityEvent.startedAt, order: .reverse)
    private var activities: [ActivityEvent]
    
    private let evaluationService = TaskEvaluationService()

    @State private var newTaskTitle: String = ""
    @State private var newTaskDetail: String = ""
    @State private var newTaskDueAt: Date = Date()
    @State private var hasDueDate: Bool = false
    @State private var newTaskKeywords: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            headerSection

            addTaskSection

            taskListSection
        }
        .padding()
    }

    private var headerSection: some View {
        HStack {
            VStack(alignment: .leading, spacing: 6) {
                Text("Tasks")
                    .font(.largeTitle)
                    .bold()

                Text("캘린더, 수동 입력, LLM 제안에서 나온 할 일을 관리합니다.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Button("오늘 활동과 비교") {
                evaluateTasks()
            }

            Button("완료된 항목 삭제") {
                deleteCompletedTasks()
            }
        }
    }

    private var addTaskSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("새 할 일")
                .font(.headline)

            TextField("예: 생산시스템관리 과제 제출", text: $newTaskTitle)
                .textFieldStyle(.roundedBorder)

            TextField("상세 설명 선택 입력", text: $newTaskDetail)
                .textFieldStyle(.roundedBorder)

            TextField("관련 키워드 예: 생산시스템관리,LMS,과제", text: $newTaskKeywords)
                .textFieldStyle(.roundedBorder)

            Toggle("마감일 있음", isOn: $hasDueDate)

            if hasDueDate {
                DatePicker(
                    "마감일",
                    selection: $newTaskDueAt,
                    displayedComponents: [.date, .hourAndMinute]
                )
            }

            HStack {
                Spacer()

                Button("추가") {
                    addTask()
                }
                .disabled(newTaskTitle.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .padding()
        .background(.quaternary)
        .clipShape(RoundedRectangle(cornerRadius: 16))
    }

    private var taskListSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("할 일 목록")
                .font(.title2)
                .bold()

            if tasks.isEmpty {
                ContentUnavailableView(
                    "등록된 할 일이 없습니다",
                    systemImage: "checklist",
                    description: Text("새 할 일을 추가해보세요.")
                )
            } else {
                List {
                    if !urgentTasks.isEmpty {
                        Section("마감 임박 / 확인 필요") {
                            ForEach(urgentTasks) { task in
                                taskRow(task)
                            }
                        }
                    }

                    if !activeTasks.isEmpty {
                        Section("진행 중 / 대기") {
                            ForEach(activeTasks) { task in
                                taskRow(task)
                            }
                        }
                    }

                    if !deferredTasks.isEmpty {
                        Section("연기됨") {
                            ForEach(deferredTasks) { task in
                                taskRow(task)
                            }
                        }
                    }

                    if !completedTasks.isEmpty {
                        Section("완료됨") {
                            ForEach(completedTasks) { task in
                                taskRow(task)
                            }
                        }
                    }
                }
            }
        }
    }

    private func taskRow(_ task: TaskItem) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(alignment: .top, spacing: 12) {
                Button {
                    toggleTask(task)
                } label: {
                    Image(systemName: task.isCompleted ? "checkmark.circle.fill" : "circle")
                        .font(.title3)
                }
                .buttonStyle(.plain)

                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(task.title)
                            .font(.headline)
                            .strikethrough(task.isCompleted)

                        if task.needsUserConfirmation {
                            Text("확인 필요")
                                .font(.caption2)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 3)
                                .background(.orange.opacity(0.2))
                                .clipShape(Capsule())
                        }
                    }

                    if let detail = task.detail,
                       !detail.isEmpty {
                        Text(detail)
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }

                    if let plannedStartAt = task.plannedStartAt {
                        Text("시작: \(plannedStartAt.formatted(date: .abbreviated, time: .shortened))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    if let dueAt = task.dueAt {
                        Text("마감: \(dueAt.formatted(date: .abbreviated, time: .shortened))")
                            .font(.caption)
                            .foregroundStyle(isOverdue(task) ? .red : .secondary)
                    }

                    if let evidence = task.evidenceSummary,
                       !evidence.isEmpty {
                        Text("근거: \(evidence)")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    if let deferredTo = task.deferredTo {
                        Text("연기일: \(deferredTo.formatted(date: .abbreviated, time: .shortened))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }

                    tagRow(task)
                }

                Spacer()

                Button {
                    deleteTask(task)
                } label: {
                    Image(systemName: "trash")
                }
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
            }

            actionButtons(task)
        }
        .padding(.vertical, 8)
    }

    private func tagRow(_ task: TaskItem) -> some View {
        HStack {
            Text(statusDisplayName(task.status))
                .font(.caption2)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(.quaternary)
                .clipShape(Capsule())

            Text(task.source)
                .font(.caption2)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(.quaternary)
                .clipShape(Capsule())

            if let keywords = task.relatedKeywords,
               !keywords.isEmpty {
                Text(keywords)
                    .font(.caption2)
                    .lineLimit(1)
                    .foregroundStyle(.secondary)
            }

            Spacer()
        }
    }

    private func actionButtons(_ task: TaskItem) -> some View {
        HStack {
            Button("대기") {
                setStatus(task, status: .pending)
            }

            Button("진행 중") {
                setStatus(task, status: .inProgress)
            }

            Button("확인 필요") {
                setStatus(task, status: .uncertain)
            }

            Button("내일로 넘김") {
                deferTaskToTomorrow(task)
            }

            Spacer()
        }
        .font(.caption)
    }

    private var urgentTasks: [TaskItem] {
        tasks.filter {
            !$0.isCompleted &&
            ($0.needsUserConfirmation || $0.status == TaskStatus.uncertain.rawValue || isDueSoon($0))
        }
    }

    private var activeTasks: [TaskItem] {
        tasks.filter {
            !$0.isCompleted &&
            $0.status != TaskStatus.deferred.rawValue &&
            !urgentTasks.contains($0)
        }
    }

    private var deferredTasks: [TaskItem] {
        tasks.filter {
            !$0.isCompleted &&
            $0.status == TaskStatus.deferred.rawValue
        }
    }

    private var completedTasks: [TaskItem] {
        tasks.filter { $0.isCompleted }
    }

    private func addTask() {
        let trimmedTitle = newTaskTitle.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedDetail = newTaskDetail.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedKeywords = newTaskKeywords.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedTitle.isEmpty else {
            return
        }

        let task = TaskItem(
            title: trimmedTitle,
            detail: trimmedDetail.isEmpty ? nil : trimmedDetail,
            source: "manual",
            status: TaskStatus.pending.rawValue,
            dueAt: hasDueDate ? newTaskDueAt : nil,
            relatedKeywords: trimmedKeywords.isEmpty ? nil : trimmedKeywords
        )

        modelContext.insert(task)

        newTaskTitle = ""
        newTaskDetail = ""
        newTaskKeywords = ""
        hasDueDate = false
        newTaskDueAt = Date()
    }

    private func toggleTask(_ task: TaskItem) {
        task.isCompleted.toggle()

        if task.isCompleted {
            task.status = TaskStatus.completed.rawValue
            task.completedAt = Date()
            task.needsUserConfirmation = false
        } else {
            task.status = TaskStatus.pending.rawValue
            task.completedAt = nil
        }
    }

    private func setStatus(_ task: TaskItem, status: TaskStatus) {
        task.status = status.rawValue
        task.isCompleted = status == .completed
        task.completedAt = status == .completed ? Date() : nil
        task.needsUserConfirmation = status == .uncertain
    }

    private func deferTaskToTomorrow(_ task: TaskItem) {
        let tomorrow = Calendar.current.date(
            byAdding: .day,
            value: 1,
            to: Date()
        ) ?? Date()

        task.status = TaskStatus.deferred.rawValue
        task.deferredTo = tomorrow
        task.needsUserConfirmation = false
        task.isCompleted = false
        task.completedAt = nil
    }

    private func deleteTask(_ task: TaskItem) {
        modelContext.delete(task)
    }
    
    private func evaluateTasks() {
        let results = evaluationService.evaluateTasks(
            tasks: tasks,
            activities: activities
        )

        evaluationService.applyEvaluationResults(results)
    }

    private func deleteCompletedTasks() {
        for task in completedTasks {
            modelContext.delete(task)
        }
    }

    private func statusDisplayName(_ rawValue: String) -> String {
        TaskStatus(rawValue: rawValue)?.displayName ?? rawValue
    }

    private func isOverdue(_ task: TaskItem) -> Bool {
        guard let dueAt = task.dueAt else {
            return false
        }

        return !task.isCompleted && dueAt < Date()
    }

    private func isDueSoon(_ task: TaskItem) -> Bool {
        guard let dueAt = task.dueAt else {
            return false
        }

        let now = Date()
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: now) ?? now

        return dueAt >= now && dueAt <= tomorrow
    }
}
