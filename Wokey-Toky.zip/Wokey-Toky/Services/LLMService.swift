//
//  LLMService.swift
//  Wokey-Toky
//
//  Created by 조수민 on 5/8/26.
//

import Foundation

struct LLMChatMessage: Codable {
    let role: String
    let content: String
}

struct LLMChatRequest: Codable {
    let model: String
    let messages: [LLMChatMessage]
    let temperature: Double
}

struct LLMTaskResponseInterpretation: Codable {
    let taskTitle: String
    let status: String
    let responseText: String?
    let deferDays: Int?
    let confidence: Double?
    let needsClarification: Bool?
    let clarificationQuestion: String?
}

struct LLMTaskResponseInterpretationResult: Codable {
    let results: [LLMTaskResponseInterpretation]
}

struct LLMChatResponse: Codable {
    struct Choice: Codable {
        struct Message: Codable {
            let role: String?
            let content: String?
        }

        let message: Message
    }

    let choices: [Choice]
}

struct ClaudeMessageRequest: Codable {
    let model: String
    let maxTokens: Int
    let system: String
    let messages: [LLMChatMessage]
    let temperature: Double

    enum CodingKeys: String, CodingKey {
        case model
        case maxTokens = "max_tokens"
        case system
        case messages
        case temperature
    }
}

struct ClaudeMessageResponse: Codable {
    struct ContentBlock: Codable {
        let type: String
        let text: String?
    }

    let content: [ContentBlock]
}

enum LLMServiceError: Error, LocalizedError {
    case invalidURL
    case missingAPIKey
    case invalidResponse
    case emptyResponse
    case serverError(String)

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "LLM endpoint URL이 올바르지 않습니다."
        case .missingAPIKey:
            return "API Key가 비어 있습니다."
        case .invalidResponse:
            return "LLM 응답 형식이 올바르지 않습니다."
        case .emptyResponse:
            return "LLM 응답 내용이 비어 있습니다."
        case .serverError(let message):
            return "LLM 서버 오류: \(message)"
        }
    }
}

final class LLMService {
    func generateDailySummary(
        log: String,
        config: LLMConfig
    ) async throws -> String {
        let prompt = buildDailySummaryPrompt(log: log)

        return try await generateWithPreferredProvider(
            systemPrompt: "너는 사용자의 macOS 작업 기록을 분석해주는 개인 작업 비서다. 답변은 한국어로 명확하고 실용적으로 작성한다.",
            userPrompt: prompt,
            temperature: 0.3,
            maxTokens: 1800,
            config: config
        )
    }
    
    func generateBriefing(
        type: BriefingType,
        context: String,
        config: LLMConfig
    ) async throws -> String {
        let prompt = buildBriefingPrompt(
            type: type,
            context: context
        )

        return try await generateWithPreferredProvider(
            systemPrompt: "너는 사용자의 할 일과 실제 Mac 활동 기록을 비교해 하루 업무 브리핑을 작성하는 개인 업무 점검 비서다. 답변은 한국어로 작성한다.",
            userPrompt: prompt,
            temperature: 0.2,
            maxTokens: 2200,
            config: config
        )
    }

    private func buildDailySummaryPrompt(log: String) -> String {
        """
        다음은 사용자의 오늘 macOS 작업 로그입니다.

        이 로그를 바탕으로 아래 형식으로 요약해주세요.

        # 오늘 요약

        ## 1. 주요 작업
        - 오늘 가장 많이 한 작업을 정리

        ## 2. 시간대별 흐름
        - 가능한 경우 시간 흐름에 따라 정리

        ## 3. 사용한 주요 앱과 자료
        - Xcode, Safari, Chrome, Finder, ChatGPT 등 주요 앱과 URL/창 제목 활용

        ## 4. 이어서 할 일
        - 다음에 바로 이어서 하면 좋은 작업을 체크리스트로 정리

        ## 5. 작업 비서의 제안
        - 사용자가 놓쳤을 수 있는 점이나 정리하면 좋은 것을 제안

        조건:
        - 과장하지 말 것
        - 로그에 없는 내용을 단정하지 말 것
        - 불확실한 내용은 "추정"이라고 표현할 것
        - 한국어로 작성할 것

        [오늘 로그]
        \(log)
        """
    }
    
    private func buildBriefingPrompt(
        type: BriefingType,
        context: String
    ) -> String {
        let briefingInstruction: String

        switch type {
        case .morning:
            briefingInstruction = """
            아침 브리핑을 작성하세요.

            목적:
            - 오늘 해야 할 일을 마감과 중요도 기준을 따라 우선순위대로 정리
            - 어제 또는 이전에 미완료/진행 중/연기된 일이 있으면 다시 반영
            - 실제 활동 기록이 이미 있는 일은 근거를 함께 제시
            - 완료 여부가 애매한 일은 확인 질문으로 분리
            """

        case .lunch:
            briefingInstruction = """
            점심 점검 브리핑을 작성하세요.

            목적:
            - 오늘 해야 하는 일 중 아직 완료되지 않은 일을 다시 점검
            - 오전 활동 기록을 바탕으로 실제로 진행했는지 판단
            - 마감이 가까운 일을 우선 강조
            - 사용자가 이미 답변한 일은 반복해서 묻지 않으
            """

        case .evening:
            briefingInstruction = """
            저녁 회고 브리핑을 작성하세요.

            목적:
            - 오늘 완료한 일, 진행 중인 일, 미완료인 일을 구분
            - 내일로 넘겨야 할 일을 분리
            - 실제 활동 기록과 사용자 답변을 근거로 상태를 판단
            - 완료 여부가 애매한 일은 확인 질문으로 정리
            """
        }

        return """

            \(briefingInstruction)

            당신의 역할:

            - 단순 요약자가 아니라, 사용자의 계획된 할 일과 실제 Mac 활동 기록을 비교하는 업무 점검 비서입니다.
            - 각 할 일에 대해 "계획", "실제 행동 근거", "판단", "다음 행동"을 분리해서 작성해야 합니다.
            - 근거가 없으면 없다고 말해야 합니다.
            - 로그에 없는 내용을 완료했다고 단정하지 마세요.
            - 불확실한 경우 반드시 "불확실" 또는 "확인 필요"라고 표현하세요.
            
            출력 형식은 반드시 아래 구조를 따르세요.
            
            # \(type.displayName)
            
            ## 1. 핵심 요약
            - 오늘 업무 상황을 2~3줄로 요약합니다.
            - 단순 감상이 아니라, 할 일과 실제 행동의 차이를 중심으로 작성합니다.

            ## 2. 우선 점검할 일
            각 항목은 아래 형식을 따르세요.

            ### 1) 할 일 제목
            - 마감/시간:
            - 현재 상태:
            - 실제 행동 근거:
            - 판단:
            - 다음 행동:

            상태는 아래 중 하나로 표현하세요.
            - 완료 가능성 높음
            - 진행 중
            - 미완료 가능성 높음
            - 확인 필요
            - 내일로 넘김

            ## 3. 실제 활동 근거 요약
            - 관련 앱, 창 제목, URL 기록을 기준으로 작성합니다.
            - 단순히 앱 이름을 나열하지 말고 어떤 할 일과 관련 있어 보이는지 연결합니다.
            
            ## 4. 확인 질문
            - 정말 확인이 필요한 질문만 작성합니다.
            - 질문은 최대 3개까지만 작성합니다.
            - 이미 사용자가 답변한 일은 다시 묻지 않습니다.
            - 질문은 사용자가 "완료 / 진행 중 / 미완료 / 내일로 넘김" 중 하나로 답하기 쉽게 작성합니다.

            ## 5. 다음 행동 제안
            - 지금 바로 하면 좋은 행동을 1~3개만 제안합니다.
            - 추상적인 조언은 피하고 구체적인 행동으로 작성합니다.

            작성 규칙:
            - 한국어로 작성합니다.
            - 과장하지 않습니다.
            - 로그에 없는 사실을 만들지 않습니다.
            - "아마 완료했을 것입니다"처럼 단정하지 않습니다.
            - 근거가 약하면 "추정" 또는 "확인 필요"라고 씁니다.
            - 문장은 짧게 씁니다.
            - 각 bullet은 너무 길지 않게 씁니다.
            - 사용자가 바로 읽고 행동할 수 있게 작성합니다.

            [컨텍스트]
            \(context)
            """
    }
    
    func interpretTaskResponse(
        userText: String,
        tasks: [TaskItem],
        config: LLMConfig
    ) async throws -> [TaskResponseInterpretation] {
        let prompt = buildTaskResponseInterpretationPrompt(
            userText: userText,
            tasks: tasks
        )

        let content = try await generateWithPreferredProvider(
            systemPrompt: "너는 사용자의 짧거나 긴 자연어 답변을 할 일 상태 변경으로 해석하는 업무 비서다. 반드시 JSON만 출력한다.",
            userPrompt: prompt,
            temperature: 0.0,
            maxTokens: 1200,
            config: config
        )

        let jsonText = extractJSON(from: content)

        guard let jsonData = jsonText.data(using: .utf8) else {
            throw LLMServiceError.invalidResponse
        }

        let parsed = try JSONDecoder().decode(
            LLMTaskResponseInterpretationResult.self,
            from: jsonData
        )

        return parsed.results.compactMap { item in
            guard let status = TaskStatus(rawValue: item.status) else {
                return nil
            }

            let deferredTo: Date?

            if let deferDays = item.deferDays {
                deferredTo = Calendar.current.date(
                    byAdding: .day,
                    value: deferDays,
                    to: Date()
                )
            } else {
                deferredTo = nil
            }

            return TaskResponseInterpretation(
                taskTitle: item.taskTitle,
                status: status,
                responseText: item.responseText ?? userText,
                deferredTo: deferredTo,
                confidence: item.confidence ?? 0.5,
                needsClarification: item.needsClarification ?? false,
                clarificationQuestion: item.clarificationQuestion
            )
        }
    }

    private func generateWithPreferredProvider(
        systemPrompt: String,
        userPrompt: String,
        temperature: Double,
        maxTokens: Int,
        config: LLMConfig
    ) async throws -> String {
        var claudeError: Error?

        if config.isClaudeConfigured {
            do {
                return try await generateWithClaude(
                    systemPrompt: systemPrompt,
                    userPrompt: userPrompt,
                    temperature: temperature,
                    maxTokens: maxTokens,
                    config: config
                )
            } catch {
                claudeError = error
            }
        }

        if config.isLocalFallbackConfigured {
            do {
                return try await generateWithOpenAICompatibleEndpoint(
                    systemPrompt: systemPrompt,
                    userPrompt: userPrompt,
                    temperature: temperature,
                    config: config
                )
            } catch {
                if let claudeError {
                    throw LLMServiceError.serverError("Claude 호출 실패 후 로컬 fallback도 실패했습니다. Claude: \(claudeError.localizedDescription) / Local: \(error.localizedDescription)")
                }

                throw error
            }
        }

        if let claudeError {
            throw LLMServiceError.serverError("Claude 호출에 실패했고 로컬 fallback이 꺼져 있습니다. \(claudeError.localizedDescription)")
        }

        if config.isClaudeEnabledResolved {
            throw LLMServiceError.missingAPIKey
        }

        throw LLMServiceError.serverError("사용 가능한 LLM 설정이 없습니다.")
    }

    private func generateWithClaude(
        systemPrompt: String,
        userPrompt: String,
        temperature: Double,
        maxTokens: Int,
        config: LLMConfig
    ) async throws -> String {
        guard let url = URL(string: config.claudeEndpointResolved) else {
            throw LLMServiceError.invalidURL
        }

        let trimmedAPIKey = config.claudeAPIKeyResolved.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedAPIKey.isEmpty else {
            throw LLMServiceError.missingAPIKey
        }

        let requestBody = ClaudeMessageRequest(
            model: config.claudeModelNameResolved,
            maxTokens: maxTokens,
            system: systemPrompt,
            messages: [
                LLMChatMessage(
                    role: "user",
                    content: userPrompt
                )
            ],
            temperature: temperature
        )

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("2023-06-01", forHTTPHeaderField: "anthropic-version")
        request.setValue(trimmedAPIKey, forHTTPHeaderField: "x-api-key")
        request.httpBody = try JSONEncoder().encode(requestBody)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw LLMServiceError.invalidResponse
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            let message = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw LLMServiceError.serverError(message)
        }

        let decoded = try JSONDecoder().decode(ClaudeMessageResponse.self, from: data)
        let content = decoded.content
            .filter { $0.type == "text" }
            .compactMap(\.text)
            .joined(separator: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard !content.isEmpty else {
            throw LLMServiceError.emptyResponse
        }

        return content
    }

    private func generateWithOpenAICompatibleEndpoint(
        systemPrompt: String,
        userPrompt: String,
        temperature: Double,
        config: LLMConfig
    ) async throws -> String {
        guard config.isEnabled else {
            throw LLMServiceError.serverError("로컬 fallback 설정이 비활성화되어 있습니다.")
        }

        guard let url = URL(string: config.endpoint) else {
            throw LLMServiceError.invalidURL
        }

        let trimmedAPIKey = config.apiKey.trimmingCharacters(in: .whitespacesAndNewlines)

        let requestBody = LLMChatRequest(
            model: config.modelName,
            messages: [
                LLMChatMessage(
                    role: "system",
                    content: systemPrompt
                ),
                LLMChatMessage(
                    role: "user",
                    content: userPrompt
                )
            ],
            temperature: temperature
        )

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        if !trimmedAPIKey.isEmpty {
            request.setValue("Bearer \(trimmedAPIKey)", forHTTPHeaderField: "Authorization")
        }

        request.httpBody = try JSONEncoder().encode(requestBody)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw LLMServiceError.invalidResponse
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            let message = String(data: data, encoding: .utf8) ?? "Unknown error"
            throw LLMServiceError.serverError(message)
        }

        let decoded = try JSONDecoder().decode(LLMChatResponse.self, from: data)

        guard let content = decoded.choices.first?.message.content,
              !content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw LLMServiceError.emptyResponse
        }

        return content
    }
    
    private func buildTaskResponseInterpretationPrompt(
        userText: String,
        tasks: [TaskItem]
    ) -> String {
        let taskList = tasks
            .filter { !$0.isCompleted }
            .map { task in
                """
                - title: \(task.title)
                  status: \(task.status)
                  source: \(task.source)
                  dueAt: \(task.dueAt?.formatted(date: .abbreviated, time: .shortened) ?? "없음")
                  evidence: \(task.evidenceSummary ?? "없음")
                """
            }
            .joined(separator: "\n")

        return """
        사용자의 자연어 답변을 읽고, 아래 할 일 목록 중 어떤 할 일의 상태를 바꿔야 하는지 해석하세요.

        사용자의 답변은 매우 짧을 수 있습니다.
        예:
        - "했어"
        - "아직"
        - "내일"
        - "진행 중"
        - "그건 끝났어"
        - "PPT는 했고 과제는 아직"

        가능한 status 값은 반드시 아래 중 하나만 사용하세요.
        - pending
        - inProgress
        - completed
        - deferred
        - uncertain

        상태 해석 규칙:
        - "완료했어", "끝냈어", "제출했어", "보냈어", "다 했어", "했어" → completed
        - "하고 있어", "진행 중", "아직 하는 중", "작업 중" → inProgress
        - "아직 안 했어", "아직", "미완료", "못 했어", "아직 제출 전" → pending
        - "내일 할게", "내일로 넘길게", "나중에 할게", "내일" → deferred
        - 어느 할 일인지 불명확하면 uncertain
        - 상태는 알겠지만 어떤 할 일인지 불명확하면 needsClarification을 true로 설정하세요.
        - 사용자가 언급하지 않은 할 일은 results에 포함하지 마세요.

        confidence 규칙:
        - 0.90 이상: 할 일과 상태가 모두 매우 명확함
        - 0.75 이상: 자동 반영해도 될 정도로 명확함
        - 0.45~0.74: 어느 정도 추정 가능하지만 사용자 확인이 필요함
        - 0.45 미만: 반영하면 안 됨. 역질문 필요

        needsClarification 규칙:
        - 사용자가 "했어", "아직", "내일"처럼 짧게 답했는데 대상 할 일이 여러 개면 true
        - "그거", "이거", "저건"처럼 지시어만 있고 대상이 불분명하면 true
        - taskTitle을 정확히 특정할 수 없으면 true
        - clarificationQuestion에는 사용자에게 다시 물어볼 문장을 작성하세요.

        taskTitle 규칙:
        - taskTitle은 반드시 제공된 할 일 제목 중 하나와 최대한 동일하게 작성하세요.
        - 불명확해서 특정할 수 없으면 가장 가능성 높은 제목을 넣되 confidence를 낮게 주고 needsClarification을 true로 설정하세요.

        반드시 JSON만 출력하세요.
        markdown 코드블록을 쓰지 마세요.
        설명 문장을 붙이지 마세요.

        출력 형식:
        {
          "results": [
            {
              "taskTitle": "할 일 제목",
              "status": "completed",
              "responseText": "사용자 답변 중 해당 부분",
              "deferDays": null,
              "confidence": 0.92,
              "needsClarification": false,
              "clarificationQuestion": null
            }
          ]
        }

        deferDays 규칙:
        - 내일로 넘김이면 1
        - 모레면 2
        - 특정 날짜를 정확히 해석하기 어려우면 1
        - deferred가 아니면 null

        [현재 할 일 목록]
        \(taskList)

        [사용자 답변]
        \(userText)
        """
    }
    
    private func extractJSON(from text: String) -> String {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)

        if trimmed.hasPrefix("{") && trimmed.hasSuffix("}") {
            return trimmed
        }

        guard let start = trimmed.firstIndex(of: "{"),
              let end = trimmed.lastIndex(of: "}") else {
            return trimmed
        }

        return String(trimmed[start...end])
    }
}
