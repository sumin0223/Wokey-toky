//
//  TaskResponseService.swift
//  Wokey-Toky
//
//  Created by 조수민 on 5/10/26.
//

import Foundation
import SwiftData

final class TaskResponseService {
    func markCompleted(
        task: TaskItem,
        modelContext: ModelContext
    ) {
        task.status = TaskStatus.completed.rawValue
        task.isCompleted = true
        task.completedAt = Date()
        task.needsUserConfirmation = false
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자가 완료로 확정했습니다."
        )

        insertResponse(
            task: task,
            responseType: "completed",
            interpretedStatus: TaskStatus.completed.rawValue,
            deferredTo: nil,
            modelContext: modelContext
        )
    }

    func markInProgress(
        task: TaskItem,
        modelContext: ModelContext
    ) {
        task.status = TaskStatus.inProgress.rawValue
        task.isCompleted = false
        task.completedAt = nil
        task.needsUserConfirmation = false
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자가 진행 중으로 확정했습니다."
        )

        insertResponse(
            task: task,
            responseType: "inProgress",
            interpretedStatus: TaskStatus.inProgress.rawValue,
            deferredTo: nil,
            modelContext: modelContext
        )
    }

    func markPending(
        task: TaskItem,
        modelContext: ModelContext
    ) {
        task.status = TaskStatus.pending.rawValue
        task.isCompleted = false
        task.completedAt = nil
        task.needsUserConfirmation = false
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자가 아직 미완료로 확정했습니다."
        )

        insertResponse(
            task: task,
            responseType: "pending",
            interpretedStatus: TaskStatus.pending.rawValue,
            deferredTo: nil,
            modelContext: modelContext
        )
    }

    func deferToTomorrow(
        task: TaskItem,
        modelContext: ModelContext
    ) {
        let tomorrow = Calendar.current.date(
            byAdding: .day,
            value: 1,
            to: Date()
        ) ?? Date()

        task.status = TaskStatus.deferred.rawValue
        task.isCompleted = false
        task.completedAt = nil
        task.needsUserConfirmation = false
        task.deferredTo = tomorrow
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자가 내일로 넘겼습니다."
        )

        insertResponse(
            task: task,
            responseType: "deferred",
            interpretedStatus: TaskStatus.deferred.rawValue,
            deferredTo: tomorrow,
            modelContext: modelContext
        )
    }

    private func insertResponse(
        task: TaskItem,
        responseType: String,
        interpretedStatus: String,
        deferredTo: Date?,
        responseText: String? = nil,
        modelContext: ModelContext
    ) {
        let response = UserTaskResponse(
            taskTitle: task.title,
            responseType: responseType,
            responseText: responseText,
            interpretedStatus: interpretedStatus,
            deferredTo: deferredTo
        )

        modelContext.insert(response)
    }

    private func appendResponseNote(
        existing: String?,
        note: String
    ) -> String {
        let timestamp = Date().formatted(date: .omitted, time: .shortened)

        if let existing,
           !existing.isEmpty {
            return "\(existing)\n[\(timestamp)] \(note)"
        } else {
            return "[\(timestamp)] \(note)"
        }
    }
    
    func applyInterpretation(
        _ interpretation: TaskResponseInterpretation,
        to task: TaskItem,
        modelContext: ModelContext
    ) {
        switch interpretation.status {
        case .completed:
            markCompletedWithText(
                task: task,
                responseText: interpretation.responseText,
                modelContext: modelContext
            )

        case .inProgress:
            markInProgressWithText(
                task: task,
                responseText: interpretation.responseText,
                modelContext: modelContext
            )

        case .pending:
            markPendingWithText(
                task: task,
                responseText: interpretation.responseText,
                modelContext: modelContext
            )

        case .deferred:
            deferWithText(
                task: task,
                responseText: interpretation.responseText,
                deferredTo: interpretation.deferredTo,
                modelContext: modelContext
            )

        case .uncertain:
            task.status = TaskStatus.uncertain.rawValue
            task.needsUserConfirmation = true
            task.evidenceSummary = appendResponseNote(
                existing: task.evidenceSummary,
                note: "사용자 답변 해석 결과 확인 필요: \(interpretation.responseText)"
            )
        }
    }
    
    private func markCompletedWithText(
        task: TaskItem,
        responseText: String,
        modelContext: ModelContext
    ) {
        task.status = TaskStatus.completed.rawValue
        task.isCompleted = true
        task.completedAt = Date()
        task.needsUserConfirmation = false
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자 답변으로 완료 확정: \(responseText)"
        )

        insertResponse(
            task: task,
            responseType: "completed",
            interpretedStatus: TaskStatus.completed.rawValue,
            deferredTo: nil,
            responseText: responseText,
            modelContext: modelContext
        )
    }

    private func markInProgressWithText(
        task: TaskItem,
        responseText: String,
        modelContext: ModelContext
    ) {
        task.status = TaskStatus.inProgress.rawValue
        task.isCompleted = false
        task.completedAt = nil
        task.needsUserConfirmation = false
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자 답변으로 진행 중 확정: \(responseText)"
        )

        insertResponse(
            task: task,
            responseType: "inProgress",
            interpretedStatus: TaskStatus.inProgress.rawValue,
            deferredTo: nil,
            responseText: responseText,
            modelContext: modelContext
        )
    }

    private func markPendingWithText(
        task: TaskItem,
        responseText: String,
        modelContext: ModelContext
    ) {
        task.status = TaskStatus.pending.rawValue
        task.isCompleted = false
        task.completedAt = nil
        task.needsUserConfirmation = false
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자 답변으로 미완료 확정: \(responseText)"
        )

        insertResponse(
            task: task,
            responseType: "pending",
            interpretedStatus: TaskStatus.pending.rawValue,
            deferredTo: nil,
            responseText: responseText,
            modelContext: modelContext
        )
    }

    private func deferWithText(
        task: TaskItem,
        responseText: String,
        deferredTo: Date?,
        modelContext: ModelContext
    ) {
        let finalDeferredTo = deferredTo ?? Calendar.current.date(
            byAdding: .day,
            value: 1,
            to: Date()
        ) ?? Date()

        task.status = TaskStatus.deferred.rawValue
        task.isCompleted = false
        task.completedAt = nil
        task.needsUserConfirmation = false
        task.deferredTo = finalDeferredTo
        task.evidenceSummary = appendResponseNote(
            existing: task.evidenceSummary,
            note: "사용자 답변으로 연기됨: \(responseText)"
        )

        insertResponse(
            task: task,
            responseType: "deferred",
            interpretedStatus: TaskStatus.deferred.rawValue,
            deferredTo: finalDeferredTo,
            responseText: responseText,
            modelContext: modelContext
        )
    }
}
