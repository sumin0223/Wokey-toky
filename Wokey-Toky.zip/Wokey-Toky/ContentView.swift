//
//  ContentView.swift
//  Wokey-Toky
//
//  Created by 조수민 on 5/7/26.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Environment(\.modelContext) private var modelContext
    @StateObject private var captureManager = ContextCaptureManager()
    @Query private var llmConfigs: [LLMConfig]
    @State private var showClaudeOnboarding = false
    
    var body: some View {
        NavigationSplitView {
            List {
                NavigationLink("Today") {
                    TodayView()
                }
                
                NavigationLink("오늘의 활동") {
                    ActivityTimelineView()
                }
                
                NavigationLink("화면 창 목록") {
                    VisibleWindowsView()
                }
                
                NavigationLink("저장된 화면 기록") {
                    WindowRecordsView()
                }
                
                NavigationLink("Tasks") {
                    TasksView()
                }
                
                NavigationLink("Calendar Import") {
                    CalendarImportView()
                }
                
                NavigationLink("Briefing") {
                    BriefingView()
                }
                
                NavigationLink("Suggestions") {
                    SuggestionsView()
                }

                NavigationLink("Summary") {
                    SummaryView()
                }

                NavigationLink("Settings") {
                    SettingsView()
                }

                NavigationLink("Privacy") {
                    PrivacyView()
                }
            }
            .navigationTitle("Wokey-Toky")
        } detail: {
            TodayView()
        }
        .environmentObject(captureManager)
        .sheet(isPresented: $showClaudeOnboarding) {
            ClaudeAPIKeyOnboardingView(
                config: llmConfigs.first,
                onComplete: {
                    showClaudeOnboarding = false
                }
            )
        }
        .onAppear {
            clearLegacyClaudeAPIKeys()
            showClaudeOnboardingIfNeeded()
        }
        .onChange(of: llmConfigs.count) { _, _ in
            clearLegacyClaudeAPIKeys()
            showClaudeOnboardingIfNeeded()
        }
    }

    private func showClaudeOnboardingIfNeeded() {
        guard !showClaudeOnboarding else {
            return
        }

        guard let config = llmConfigs.first else {
            showClaudeOnboarding = true
            return
        }

        let hasClaudeKey = !config.claudeAPIKeyResolved
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .isEmpty

        if config.isClaudeEnabledResolved && !hasClaudeKey {
            showClaudeOnboarding = true
        }
    }

    private func clearLegacyClaudeAPIKeys() {
        var didChange = false

        for config in llmConfigs {
            if let legacyKey = config.claudeAPIKey,
               !legacyKey.isEmpty {
                config.claudeAPIKey = ""
                config.updatedAt = Date()
                didChange = true
            }
        }

        if didChange {
            try? modelContext.save()
        }
    }
}
